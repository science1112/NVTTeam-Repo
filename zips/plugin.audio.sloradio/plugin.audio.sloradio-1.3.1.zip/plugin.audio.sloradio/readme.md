# Slovenske radijske postaje za XBMC/KODI

Vse znane radijske postaje(64), katere lahko poslušate preko intenrneta.