# -*- coding: utf-8 -*-

import datetime,xbmc,xbmcplugin,xbmcgui,xbmcaddon

class main:
    def __init__(self):
        while (not xbmc.abortRequested):
            if xbmcaddon.Addon().getSetting("subscriptions_update") == 'true':
                try:
                    t1 = datetime.datetime.strptime(xbmcaddon.Addon().getSetting("subscriptions_run"), "%Y-%m-%d %H:%M:%S.%f")
                    t2 = datetime.datetime.now()
                    hoursList = [2, 5, 10, 15, 24]
                    interval = int(xbmcaddon.Addon().getSetting("subscriptions_interval"))
                    update = abs(t2 - t1) > datetime.timedelta(hours=hoursList[interval])
                    if update is False: raise Exception()
                    if not (xbmc.Player().isPlaying() or xbmc.getCondVisibility('Library.IsScanningVideo')):
                        xbmc.executebuiltin('RunPlugin(plugin://plugin.video.series.hd/?action=library_service)')
                        xbmcaddon.Addon().setSetting('subscriptions_run', datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))
                except:
                    pass
            xbmc.sleep(1000)

main()