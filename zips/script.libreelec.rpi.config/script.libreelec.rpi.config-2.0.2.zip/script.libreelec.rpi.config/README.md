LibreElec RPi Config
=============================

Unofficial Raspberry Pi configuration add-on for LibreElec.
