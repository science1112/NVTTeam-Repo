NVTTeam Rasoberry Pi Config
=============================

NVTTeam Raspberry Pi configuration add-on for OpenELEC.
