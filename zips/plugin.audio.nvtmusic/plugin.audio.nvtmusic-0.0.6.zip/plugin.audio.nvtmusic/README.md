plugin.audio.nvtmusic
=====================

NVT Music is a new way to listen and discover music thought XBMC
