# Aeon Nox 5: NVT
A modded version of [Aeon Nox 5]

**Branches guide:**
 - **master:** Kodi v18 Codename L****
 - **krypton:** Kodi v17 Codename Krypton
 - **jarvis:** Kodi v16 Codename Jarvis
 - **isengard:** Kodi v15 Codename Isengard
 - **helix:** Kodi v14 Codename Helix


**ALL OTHER BRANCHES SHOULD NOT BE USED OR INSTALLED**
